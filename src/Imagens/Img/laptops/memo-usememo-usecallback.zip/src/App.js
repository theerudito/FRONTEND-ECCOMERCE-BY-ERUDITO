import { useEffect, useState, useMemo, useCallback } from "react";
import { List } from "./components/Lists";
import "./styles.css";

const inicialValues = [
	{ id: 1, name: "jorge" },
	{ id: 2, name: "erudito" }
];

// Ejemplo de memo se ejecuta cuanda cambian sus propiedades
// const user = memo() =>{
// proceso
// }

// Ejemplo de useMemo solo se ejecutara si cambia un valor
// const filterUser = useMemo(() => proceso, [search, users])

// Ejemplo de useCallBack    useCallBack(() => {},[])

export default function App() {
	const [users, setUsers] = useState(inicialValues);
	const [text, setText] = useState("");
	const [search, setSearch] = useState("");

	const handleAdd = () => {
		const newUser = { id: users.length + 1, name: text };
		setUsers([...users, newUser]);
	};

	const handleSearch = () => {
		console.log("search");
		setSearch(text);
	};
	// propiedad computada no es mas que una funcion q retorna un valor
	// useMemo en Accion
	const usersFilter = useMemo(
		() =>
			users.filter((user) => {
				console.log("filter process");
				return user.name.toLowerCase().includes(search.toLowerCase());
			}),
		[search, users]
	);

	// useCallBack en action
	const handleDelete = useCallback(
		(Userid) => {
			setUsers(users.filter((user) => user.id !== Userid));
		},
		[users]
	);

	// useCallBack
	const printUsers = useCallback(() => {
		console.log("printUSers ", users);
	}, [users]);

	// es recomendado usar el efecto para q no renderice muchas veces
	useEffect(() => {
		//vamos a imprimir un texto y verificar cuantas veces renderiza
		console.log("app render");
	}, []);

	// efecto con useCallback
	useEffect(() => {
		printUsers();
	}, [users, printUsers]);
	return (
		<>
			<input
				type="text"
				value={text}
				onChange={(e) => setText(e.target.value)}
			/>
			<button onClick={handleAdd}>Add</button>
			<button onClick={handleSearch}>Search</button>

			<List users={usersFilter} handleDelete={handleDelete} />
		</>
	);
}
