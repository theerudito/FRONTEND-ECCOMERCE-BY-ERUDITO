import { useEffect, memo } from "react";
import { Item } from "./Item";

// memo memoriza un componente en base a su property
// es decir el va a memorizar cuando sus propiedades sean iguales
// el componente no va a volver a renderizar
// para usar ponemos memo y envolvemos todo el componente memo(componete)
// como el ejemplo abajo
export const List = memo(({ users, handleDelete }) => {
	useEffect(() => {
		console.log("List Render");
	});

	return (
		<>
			<ul>
				{users.map((user) => (
					<Item user={user} key={user.id} handleDelete={handleDelete} />
				))}
			</ul>
		</>
	);
});
